//
//  jQuery version of the postDynamicForm.js
//
(function($) {
    "use strict";
    
    /**
     * Utility method to dynamically create a form and elements within
     * that form and submit it.
     * @param {String} url of the component
     * @param {Object} childParams child parameters to convert to 
     *                 children of the submitted form
     * @param {String} formParams additional parameters to add to the form
     *                 before creation.
     */
    $.fn.postDynamicForm = function(url, childParams, formParams, event) {
        var body = $('body');
    
        // If the url contains any parameters strip them off and add 
        // them to the child parameters.
        if (url.indexOf('?') > -1) {
            var parts = url.split('?');
            url = parts[0];
            jQuery.extend(childParams, decodeURIComponent(parts[1]));
        }
    
        var formParameters = {
                // tag:'form', 
                method:'POST', 
                action: url
        };
    
        if (formParams != null && !jQuery.isEmptyObject(formParams)) {
            jQuery.extend(true, formParameters, formParams);
        }
    
        if (event && event.ctrlKey) {
            jQuery.extend(formParameters, {target: '_blank'});
            event.stopPropagation();
            event.preventDefault();
        }
        
        var form = $("<form/>");
        form.attr(formParameters);
        body.append(form);
        
        form.hide();
    
        for (var name in childParams) {
            if (name != null && name != '') {
                var values = childParams[name];
                if (values != null && (typeof values == 'array')) {
                    // 'select multiple' type elements like checkbox, listbox or lookup send these
                    // create one input for each value with same name
                    for (var i = 0; i < values.length; i++) {
                        form.append("<input name='" + name + "' value= '" + values[i] + "' />");
                    }
                } else {
                    form.append("<input name='" + name + "' value= '" + values + "' />");
                }
            }
        }            
    
        form.submit();
    };
    
    /**
     * Utility method to dynamically create a form and elements within
     * that form and submit it to a new or existing named window.
     * @param {String} url - url of the component
     * @param {Object} childParams - child parameters to convert to 
     *                 children of the submitted form
     * @param {String} windowName - name of the window to submit to
     * @param {Object} event - the click event which triggered this window creation.  Needed to break through popup-blockers.
     * @param {String} windowOptions - list of window options if it's a popup window.
     * @param {Number} width - width of the new window if it's a popup window
     * @param {Number} height - height of the new window if it's a popup window
     * @param {Boolean} moveFocus - whether or not to move focus to the new popup after it is submitted to.
     *  
     */
    $.fn.postDynamicFormToWindow= function(url, childParams, windowName, event, windowOptions, width, height, moveFocus) {
    	var formParams = {};
    	if (windowName != null) {
    		formParams = { target: windowName};
    	}
    	
    	var newWindow = null;
    	if (windowOptions != null) {

    		if (width != undefined && height != undefined) {
            	var left = (screen.width/2)-(width/2);
            	var top = (screen.height/2)-(height/2);
            	windowOptions += ",height="+height+",width="+width+",top="+top+",left="+left;
        	}

        	newWindow = window.open("_blank", windowName, windowOptions);
    	}
    	
    	$(this).postDynamicForm(url, childParams, formParams, event);
    	
    	if (moveFocus == true && newWindow != null) {
    		newWindow.focus();
    	}
    	
    };

}(jQuery));
