/**
 * Create a custom jquery-ui dialog that lets the user know we're doing something that will take some time
 */
(function($) {
    'use strict';

    $.widget('util.pleaseWait', {
    	options : {
	    	/**
	    	 * @cfg
	    	 *  where the spinny gif image is stored
	    	 */
	    	imageUri: 'images/ajax-loader.gif',
	    	
	    	// Defaults
			modal         : true,
			resizable     : false,
			width         : 100,
			height        : 80,
			draggable     : false,
			closeOnEscape : false,
			autoOpen      : true,
			show          : {effect : 'fadeIn'},
			hide          : {effect : 'fadeOut'}
    	},
    	
    	/**
    	 * create the widget
    	 */
    	_create: function () {
    		// Create the div that will become our dialog
    		this.dialogDiv = $('<div>', {id : 'ui-tda-please-wait'});

    		// add runtime specific settings to the options.
    		$.extend(this.options, { appendTo : this.element });

    		// turn it into a dialog
    		this.actualDialog = $(this.dialogDiv).dialog(this.options);

    		// make sure we know that an instance has been created so we don't keep creating them
    		$.util.pleaseWait.instance = this.actualDialog;
    		
    		// create the container inside the dialog
    		this.pleaseWaitContainer = $('<div>').addClass('ui-tda-please-wait-container').appendTo(this.dialogDiv);
    		
    		// then add in the rest
    		this.img = $('<img>', {src : this.options.imageUri});
    		$('<p>').append('Please Wait ').append(this.img).appendTo(this.pleaseWaitContainer);
    		
    		// then take out the ability for the user to close the box
    		$('#ui-tda-please-wait').parent().find('button.ui-dialog-titlebar-close').remove();
    	},
    	/**
    	 * hide the dialog from view
    	 */
    	hide : function () {
    		$(this.dialogDiv).dialog('close');
    	},
    	/**
    	 * show the dialog on the screen
    	 */
    	show : function () {
    		$(this.dialogDiv).dialog('open');
    	}
    });
    
    /**
     * extending this widget to include an instance of itself
     */
    $.extend($.util.pleaseWait, {
    	instance : null
    });
    
    /**
     * Show the please wait dialog, creating it first, if needed
     */
    $.fn.showTDAPleaseWait = function () {
    	// if there isn't currently a please wait dialog created for this element, add it in
    	if ($.util.pleaseWait.instance == null) {
    		$(this).pleaseWait();
    	} else {
    		// otherwise, simply show the dialog
        	$(this).pleaseWait('show');
    	}
    };

    /**
     * hide the please wait dialog
     */
    $.fn.hideTDAPleaseWait = function () {
    	// if we have something to hide, hide it
    	if ($.util.pleaseWait.instance != null) {
        	$(this).pleaseWait('hide');
    	}    	
    };
    
    // Backward compatibility fix provided by core for indexOf for Array
    // Production steps of ECMA-262, Edition 5, 15.4.4.14
    // Reference: http://es5.github.io/#x15.4.4.14
    if (!Array.prototype.indexOf) {
        Array.prototype.indexOf = function(searchElement, fromIndex) {

            var k;

            // 1. Let o be the result of calling ToObject passing
            // the this value as the argument.
            if (this == null) {
                throw new TypeError('"this" is null or not defined');
            }

            var o = Object(this);

            // 2. Let lenValue be the result of calling the Get
            // internal method of o with the argument "length".
            // 3. Let len be ToUint32(lenValue).
            var len = o.length >>> 0;

            // 4. If len is 0, return -1.
            if (len === 0) {
                return -1;
            }

            // 5. If argument fromIndex was passed let n be
            // ToInteger(fromIndex); else let n be 0.
            var n = +fromIndex || 0;

            if (Math.abs(n) === Infinity) {
                n = 0;
            }

            // 6. If n >= len, return -1.
            if (n >= len) {
                return -1;
            }

            // 7. If n >= 0, then Let k be n.
            // 8. Else, n<0, Let k be len - abs(n).
            // If k is less than 0, then let k be 0.
            k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

            // 9. Repeat, while k < len
            while (k < len) {
                // a. Let Pk be ToString(k).
                // This is implicit for LHS operands of the in operator
                // b. Let kPresent be the result of calling the
                // HasProperty internal method of o with argument Pk.
                //   This step can be combined with c
                // c. If kPresent is true, then
                //    i.  Let elementK be the result of calling the Get
                //        internal method of o with the argument ToString(k).
                //   ii.  Let same be the result of applying the
                //        Strict Equality Comparison Algorithm to
                //        searchElement and elementK.
                //  iii.  If same is true, return k.
                if (k in o && o[k] === searchElement) {
                    return k;
                }
                k++;
            }
            return -1;
        };
    };

}(jQuery));

